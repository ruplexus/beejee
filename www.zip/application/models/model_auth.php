<?php

	class Model_Auth extends Model {

		public function get_data(){
			return array();
		}

	}