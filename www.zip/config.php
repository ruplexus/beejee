<?php

	define('CORE_DIR', $_SERVER['DOCUMENT_ROOT'].'/application/core/');
	define('CONTROLLERS_DIR', $_SERVER['DOCUMENT_ROOT'].'/application/controllers/');
	define('MODELS_DIR', $_SERVER['DOCUMENT_ROOT'].'/application/models/');
	define('VIEW_DIR', $_SERVER['DOCUMENT_ROOT'].'/application/view/');

	// настройки БД
	define('DB_HOST', 'localhost');
	define('DB_USER', 'root');
	define('DB_PASSWORD', '');
	define('DB_BNAME', 'tasks');