<?php

	require_once($_SERVER['DOCUMENT_ROOT'].'/application/bootstrap.php');